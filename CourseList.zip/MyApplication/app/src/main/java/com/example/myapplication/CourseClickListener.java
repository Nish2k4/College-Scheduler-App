package com.example.myapplication;

import androidx.cardview.widget.CardView;

import com.example.myapplication.Models.Courses;

public interface CourseClickListener {
    void onClick(Courses course);
    void onLongClick(Courses courses, CardView cardView);

    void onEditClick(Courses courses);

}
