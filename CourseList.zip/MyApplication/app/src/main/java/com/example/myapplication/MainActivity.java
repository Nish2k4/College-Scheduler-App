package com.example.myapplication;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.SearchView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.example.myapplication.Adapters.CourseListAdapter;
import com.example.myapplication.Database.RoomDB;
import com.example.myapplication.Models.Courses;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.cardview.widget.CardView;
import androidx.navigation.FloatingWindow;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.example.myapplication.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener{

    RecyclerView recyclerView;
    CourseListAdapter courseListAdapter;
    List<Courses> courses = new ArrayList<>();

    RoomDB database;
    FloatingActionButton fab_add;
    SearchView searchView_home;
    Courses selectedCourse;



    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarMain.toolbar);
        binding.appBarMain.toolbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        recyclerView = findViewById(R.id.menu_courses_list);
        fab_add = findViewById(R.id.fab_add);
        searchView_home = findViewById(R.id.searchView_home);


        database = RoomDB.getInstance(this);
        courses = database.mainDAO().getAllCoursesOrdered();

        updateRecycler(courses);

        fab_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CourseListActivity.class);
                startActivityForResult(intent,101);
            }
        });


        searchView_home.setQueryHint("Search course or instructor...");
        searchView_home.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filter(newText);
                return true;
            }
        });

        searchView_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchView_home.setIconified(false);
            }
        });


    }

    private void filter(String newText) {
        List<Courses> filteredList = new ArrayList<>();
        for (Courses singleCourse : courses) {
            if (singleCourse.getCourse().toLowerCase().contains(newText.toLowerCase())
            || singleCourse.getInstructor().toLowerCase().contains(newText.toLowerCase())) {
                filteredList.add(singleCourse);
            }
        }
        courseListAdapter.filterList(filteredList);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 101) {
            if (resultCode == Activity.RESULT_OK) {
                Courses new_courses = (Courses) data.getSerializableExtra("course");
                database.mainDAO().insert(new_courses);
                courses.clear();
                courses.addAll(database.mainDAO().getAllCoursesOrdered());
                courseListAdapter.notifyDataSetChanged();
            }
        } else if (requestCode == 102) {
            if (resultCode == Activity.RESULT_OK) {
                Courses new_courses  = (Courses) data.getSerializableExtra("course");
                database.mainDAO().update(new_courses.getID(), new_courses.getCourse(),
                        new_courses.getInstructor(), new_courses.getDetails(), new_courses.getSection(),
                        new_courses.getLocation(), new_courses.getDate());
                courses.clear();
                courses.addAll(database.mainDAO().getAllCoursesOrdered());
                courseListAdapter.notifyDataSetChanged();
            }
        }
    }

    private void updateRecycler(List<Courses> courses) {
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new StaggeredGridLayoutManager(1, LinearLayoutManager.VERTICAL));
        courseListAdapter = new CourseListAdapter(MainActivity.this, courses, courseClickListener);
        recyclerView.setAdapter(courseListAdapter);
    }

    private final CourseClickListener courseClickListener = new CourseClickListener() {
        @Override
        public void onClick(Courses courses) {
            Intent intent = new Intent(MainActivity.this, CourseListActivity.class);
            intent.putExtra("old_course", courses);
            startActivityForResult(intent, 102);
        }

        @Override
        public void onLongClick(Courses courses, CardView cardView) {
            selectedCourse = new Courses();
            selectedCourse = courses;
            showPopup(cardView);

        }
        @Override
        public void onEditClick(Courses courses) {
            showEditConfirmationDialog(courses);
        }
    };

    private void showPopup(CardView cardView) {
        PopupMenu popupMenu = new PopupMenu(this, cardView);
        popupMenu.setOnMenuItemClickListener(this);
        popupMenu.inflate(R.menu.popup_menu);
        popupMenu.show();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
       if (item.getItemId() == R.id.pin) {
            if (selectedCourse.isPinned()) {
                database.mainDAO().pin(selectedCourse.getID(), false);
                Toast.makeText(MainActivity.this, "Unpinned!", Toast.LENGTH_SHORT).show();
            } else {
                database.mainDAO().pin(selectedCourse.getID(), true);
                Toast.makeText(MainActivity.this, "Pinned!", Toast.LENGTH_SHORT).show();
            }

           List<Courses> allCourses = database.mainDAO().getAllCoursesOrdered();


            courses.clear();
            courses.addAll(allCourses);
            courseListAdapter.notifyDataSetChanged();
            return true;
        } else if (item.getItemId() == R.id.delete) {
           AlertDialog.Builder builder = new AlertDialog.Builder(this);
           builder.setTitle("Confirm Deletion");
           builder.setMessage("Are you sure you want to delete this course?");
           builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
               @Override
               public void onClick(DialogInterface dialog, int which) {
                   // User clicked Yes, proceed with deletion
                   database.mainDAO().delete(selectedCourse);

                   runOnUiThread(new Runnable() {
                       @Override
                       public void run() {
                           courses.clear();
                           courses.addAll(database.mainDAO().getAllCoursesOrdered());
                           courseListAdapter.notifyDataSetChanged();
                       }
                   });
                   Toast.makeText(MainActivity.this, "Course Deleted!", Toast.LENGTH_SHORT).show();
               }
           });
           builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
               @Override
               public void onClick(DialogInterface dialog, int which) {
                   // User clicked No, do nothing or provide feedback
                   Toast.makeText(MainActivity.this, "Deletion Cancelled", Toast.LENGTH_SHORT).show();
               }
           });

           AlertDialog alertDialog = builder.create();
           alertDialog.show();
           return true;
       }
        return false;
    }
    private void showEditConfirmationDialog(Courses editedCourse) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirm Edit");
        builder.setMessage("Are you sure you want to edit this course?");

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // User clicked Yes, proceed with editing
                Intent intent = new Intent(MainActivity.this, CourseListActivity.class);
                intent.putExtra("old_course", editedCourse);
                startActivityForResult(intent, 102);
            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // User clicked No, do nothing
                Toast.makeText(MainActivity.this, "Edit Cancelled", Toast.LENGTH_SHORT).show();
            }
        });

        // Show the AlertDialog
        builder.show();

    }
}