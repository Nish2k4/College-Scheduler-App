package com.example.collegeschedulerapp.Database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.collegeschedulerapp.Models.TD;

import java.util.List;

@Dao
public interface TDDao {
    @Insert
    void insert(TD td);

    @Query("SELECT * FROM todo ORDER BY id ASC")
    List<TD> getAll();

    @Query("SELECT * FROM todo WHERE id = :id")
    TD getById(int id);

    @Update
    void update(TD td);

    @Delete
    void delete(TD td);
}
