package com.example.collegeschedulerapp.Adapters;

import android.content.Context;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.collegeschedulerapp.Database.RoomDB;
import com.example.collegeschedulerapp.Models.TD;
import com.example.collegeschedulerapp.R;

import java.util.List;

public class TDAdapter extends RecyclerView.Adapter<TDAdapter.TDHolder> {

    List<TD> todos;
    Context context;
    ItemClicked itemClicked;
    ViewGroup parent;
    RoomDB database;

    public TDAdapter(List<TD> list, Context context, RoomDB roomDB, ItemClicked itemClicked) {
        todos = list;
        this.context = context;
        this.database = roomDB;
        this.itemClicked = itemClicked;
    }

    @NonNull
    @Override
    public TDHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.note_container_layout, parent, false);
        this.parent = parent;
        return new TDHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TDHolder holder, int position) {
        TD td = todos.get(position);
        holder.bind(td);
    }

    @Override
    public int getItemCount() {
        return todos.size();
    }

    class TDHolder extends RecyclerView.ViewHolder {

        TextView taskname;
        TextView duedate;
        TextView course;
        CheckBox statuschk;
        ImageView imgEdit;

        public TDHolder(@NonNull final View itemView) {
            super(itemView);
            taskname = itemView.findViewById(R.id.txt_td_taskname);
            duedate = itemView.findViewById(R.id.txt_td_duedate);
            course = itemView.findViewById(R.id.txt_td_course);
            statuschk = itemView.findViewById(R.id.txt_td_status);
            imgEdit = itemView.findViewById(R.id.img_td_edit);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (duedate.getMaxLines() == 1) {
                        duedate.setMaxLines(Integer.MAX_VALUE);
                    } else {
                        duedate.setMaxLines(1);
                    }
                    notifyDataSetChanged();
                    TransitionManager.beginDelayedTransition(parent);
                }
            });

            imgEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        itemClicked.onClick(todos.get(getAdapterPosition()), view);
                    }
                }
            });
        }

        public void bind(TD td) {
            taskname.setText(td.getTaskname());
            duedate.setText(td.getDuedate());
            course.setText(td.getCourse());
            statuschk.setChecked(td.getStatus() == 1);
        }
    }

    public interface ItemClicked {
        void onClick(TD td, View view);
    }
}

