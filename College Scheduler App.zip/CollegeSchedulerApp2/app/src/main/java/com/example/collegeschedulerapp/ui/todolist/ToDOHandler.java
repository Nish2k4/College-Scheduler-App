package com.example.collegeschedulerapp.ui.todolist;

import android.content.Context;
import androidx.room.Room;

import com.example.collegeschedulerapp.Database.RoomDB;
import com.example.collegeschedulerapp.Database.TDDao;
import com.example.collegeschedulerapp.Models.TD;

import java.util.List;

public class ToDOHandler {
    private TDDao tdDao;

    public ToDOHandler(Context context) {
        RoomDB database = Room.databaseBuilder(context, RoomDB.class, "app-database").build();
        tdDao = (TDDao) database.mainDAO();
    }

    public void create(TD td) {
        tdDao.insert(td);
    }

    public List<TD> readAll() {
        return tdDao.getAll();
    }

    public TD readById(int id) {
        return tdDao.getById(id);
    }

    public void update(TD td) {
        tdDao.update(td);
    }

    public void delete(TD td) {
        tdDao.delete(td);
    }
}


