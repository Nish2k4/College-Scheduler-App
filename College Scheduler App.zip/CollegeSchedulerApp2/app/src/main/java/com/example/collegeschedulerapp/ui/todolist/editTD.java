package com.example.collegeschedulerapp.ui.todolist;

import android.content.Intent;
import android.os.Bundle;
import android.transition.TransitionManager;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.collegeschedulerapp.Database.RoomDB;
import com.example.collegeschedulerapp.Models.TD;
import com.example.collegeschedulerapp.R;

public class editTD extends AppCompatActivity {
    EditText edt_edit_taskname, edt_edit_duedate, edt_edit_course;
    CheckBox edt_edit_status;
    Button btnCancel, btnSave;


    LinearLayout linearLayout;

    RoomDB database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_td);

        Intent intent = getIntent();

        linearLayout = findViewById(R.id.btn_holder);

        edt_edit_taskname = findViewById(R.id.edt_edit_taskname);
        edt_edit_duedate = findViewById(R.id.edt_edit_duedate);
        edt_edit_course = findViewById(R.id.edt_edit_course);
        edt_edit_status = findViewById(R.id.edt_edit_status);

        btnCancel = findViewById(R.id.btnCancel);
        btnSave = findViewById(R.id.btnSave);

        database = RoomDB.getInstance(this);

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean isComplete = edt_edit_status.isChecked();
                int status = isComplete ? 1 : 0;
                TD td = new TD(edt_edit_taskname.getText().toString(), edt_edit_duedate.getText().toString(),
                        edt_edit_course.getText().toString(), status);
                td.setId(intent.getIntExtra("id", 1));

                updateTodoTask(td);

                onBackPressed();
            }
        });

        edt_edit_taskname.setText(intent.getStringExtra("taskname"));
        edt_edit_duedate.setText(intent.getStringExtra("duedate"));
        edt_edit_course.setText(intent.getStringExtra("course"));
        int taskstatus = intent.getIntExtra("status", -1);
        edt_edit_status.setChecked(taskstatus == 1);
    }

    private void updateTodoTask(TD td) {
        database.mainDAO().updateTodoTask(td);
        Toast.makeText(editTD.this, "To Do Task Updated Successfully", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        btnSave.setVisibility(View.GONE);
        btnCancel.setVisibility(View.GONE);
        TransitionManager.beginDelayedTransition(linearLayout);
        super.onBackPressed();
    }
}