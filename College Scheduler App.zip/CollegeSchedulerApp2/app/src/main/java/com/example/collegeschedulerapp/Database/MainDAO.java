package com.example.collegeschedulerapp.Database;


import static androidx.room.OnConflictStrategy.REPLACE;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.collegeschedulerapp.Models.Courses;
import com.example.collegeschedulerapp.Models.TD;

import java.util.List;

@Dao
public interface MainDAO {
    @Insert(onConflict = REPLACE)
    void insert(Courses courses);

    @Query("SELECT * FROM courses ORDER BY pinned DESC, id DESC")
    List<Courses> getAllCoursesOrdered();

    @Query("UPDATE courses SET course = :course, instructor = :instructor, details = :details, section = :section, location = :location, date = :date WHERE ID = :id")
    void update(int id, String course, String instructor, String details, String section, String location, String date);

    @Delete
    void delete(Courses courses);

    @Query("UPDATE courses SET pinned = :pin WHERE ID = :id")
    void pin(int id, boolean pin);

    // TD methods
    @Insert
    void insertTD(TD td);

    @Query("SELECT * FROM todo " +
            "ORDER BY CASE WHEN :sortby = 1 THEN status END DESC, " +
            "CASE WHEN :sortby = 2 THEN course END ASC, " +
            "CASE WHEN :sortby = 3 THEN duedate END ASC, " +
            "CASE WHEN :sortby = 4 THEN taskname END ASC")
    List<TD> readtds(int sortby);

    @Query("SELECT * FROM todo WHERE id = :tdid")
    TD readatd(int tdid);

    @Query("DELETE FROM Todo WHERE id = :tdId")
    void deleteTD(int tdId);

    @Update
    void updateTodoTask(TD td);
}
