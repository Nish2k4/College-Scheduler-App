package com.example.collegeschedulerapp.ui.todolist;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import com.example.collegeschedulerapp.Adapters.TDAdapter;
import com.example.collegeschedulerapp.Database.RoomDB;
import com.example.collegeschedulerapp.Models.TD;
import com.example.collegeschedulerapp.R;
import com.example.collegeschedulerapp.databinding.FragmentToDoListBinding;

import java.util.ArrayList;

public class ToDoListFragment extends Fragment {

    ImageButton imgButton;
    ArrayList<TD> tds;
    RecyclerView recyclerView;
    TDAdapter tdAdapter;

    RoomDB database;
    int sortBy = 0;
    private FragmentToDoListBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ToDoListViewModel toDoListViewModel =
                new ViewModelProvider(this).get(ToDoListViewModel.class);

        binding = FragmentToDoListBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textTodolist;
        toDoListViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);

        imgButton = binding.imageButton;

        imgButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater inflatr = LayoutInflater.from(requireContext());
                View viewInput = inflatr.inflate(R.layout.td_input_layout, null, false);
                EditText editTextTaskName = viewInput.findViewById(R.id.in_taskname);
                EditText editTextDueDate = viewInput.findViewById(R.id.in_duedate);
                EditText inCourse = viewInput.findViewById(R.id.in_course);
                CheckBox inStatus = viewInput.findViewById(R.id.in_status);

                new AlertDialog.Builder(requireContext())
                        .setView(viewInput)
                        .setTitle("Add To Do Task")
                        .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String taskName = editTextTaskName.getText().toString();
                                String dueDate = editTextDueDate.getText().toString();
                                String course = inCourse.getText().toString();
                                boolean isComplete = inStatus.isChecked();
                                int status = isComplete ? 1 : 0;

                                TD td = new TD(taskName, dueDate, course, status);
                                try {
                                    database.mainDAO().insertTD(td);
                                    // Insertion was successful
                                    Toast.makeText(requireContext(), "To Do Task Saved Successfully", Toast.LENGTH_SHORT).show();
                                    loadTds(sortBy);
                                } catch (Exception e) {
                                    // Insertion failed, handle the exception
                                    Toast.makeText(requireContext(), "To Do Task could not be Saved", Toast.LENGTH_SHORT).show();
                                    e.printStackTrace(); // Log the exception for debugging purposes
                                }
                                dialog.cancel();
                            }
                        }).show();
            }
        });

        recyclerView = binding.recycler;
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        ItemTouchHelper.SimpleCallback itc = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                database.mainDAO().deleteTD(tds.get(viewHolder.getAdapterPosition()).getId());
                tds.remove(viewHolder.getAdapterPosition());
                tdAdapter.notifyItemRemoved(viewHolder.getAdapterPosition());
            }
        };
        ItemTouchHelper ITH = new ItemTouchHelper(itc);
        ITH.attachToRecyclerView(recyclerView);

        // Initialize the Room database
        database = RoomDB.getInstance(requireContext());

        loadTds(sortBy);

        return root;
    }

    public ArrayList<TD> readTds(int sortby) {
        return new ArrayList<>(database.mainDAO().readtds(sortby));
    }

    public void loadTds(int sortby) {
        tds = readTds(sortby);
        tdAdapter = new TDAdapter(tds, requireContext(), database, new TDAdapter.ItemClicked() {
            @Override
            public void onClick(TD td, View view) {
                edittd(td.getId(), view);
            }
        });
        recyclerView.setAdapter(tdAdapter);
    }

    private void edittd(int tdid, View view) {
        TD td = database.mainDAO().readatd(tdid);
        Intent intent = new Intent(requireContext(), editTD.class);
        intent.putExtra("taskname", td.getTaskname());
        intent.putExtra("duedate", td.getDuedate());
        intent.putExtra("course", td.getCourse());
        intent.putExtra("status", td.getStatus());
        intent.putExtra("id", td.getId());
        ActivityOptionsCompat oc = ActivityOptionsCompat.makeSceneTransitionAnimation(requireActivity(), view, ViewCompat.getTransitionName(view));
        startActivityForResult(intent, 1, oc.toBundle());
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 ) {
            loadTds(sortBy);
        }
    }
}